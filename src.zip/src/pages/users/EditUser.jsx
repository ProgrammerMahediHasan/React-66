import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditUser = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { userId } = useParams();

  const [user, setUser] = useState({
    id: '',
    username: '',
    password: '',
    email: '',
    address: '',
    status: '',
  });

  const navigate = useNavigate();

  // Fetch user data
  function fetchUser() {
   axios({
  url: `${baseUrl}/user/find/${userId}`,
  method: "GET",
  data: {}
})
.then((res) => {
  console.log(res.data.user);
  setUser({
    id: res.data.user.id,
    username: res.data.user.username,
    password: res.data.user.password,
    email: res.data.user.email,
    address: res.data.user.address,
    status: res.data.user.status
  });
})

      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchUser();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/user/update`,
      method: "PUT",
      data:  user 
    })
      .then((res) => {
        console.log(res.data);
        navigate("/user");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
        <div
        style={{
          maxWidth: '800px', // width increased
          margin: '20px auto',
          padding: '20px',
          border: '1px solid #ccc',
          borderRadius: '8px'
        }}
        >

      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Edit user</h3>

      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="">UserName</label> <br />
          <input
            value={user.username}
            name='username'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div>
          <label htmlFor="">Password</label> <br />
          <input
            value={user.password}
            name='password'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div>
          <label htmlFor="">Email</label> <br />
          <input
            value={user.email}
            name='email'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div>
          <label htmlFor="">Address</label> <br />
          <input
            value={user.address}
            name='address'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div className="mb-3">
  <label htmlFor="status" className="form-label">Status</label>
  <select
    id="status"
    name="status"
    value={user.status}
    onChange={handleChange}
    className="form-control"
  >
    <option value="">Select status</option>
    <option value="active">Active</option>
    <option value="inactive">Inactive</option>
  </select>
</div>


        <br />
        <br />
        <div>
          <button type="submit" className="btn btn-success">Update</button>
        </div>
      </form>
    </div>
  );
};

export default EditUser;
