import axios from "axios";
import React, { useEffect, useState } from "react";

const PaySumRep = () => {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch payroll summary
  useEffect(() => {
    axios
      .get("http://localhost:8080/PHP_Converted/admin/api/payroll_summary/")
      .then((res) => {
        setEmployees(res.data.employee_salary || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setError("Failed to fetch payroll data");
        setLoading(false);
      });
  }, []);

  // Filter by employee name
  const filteredEmployees = employees.filter((emp) =>
    emp.emp_name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container-fluid px-2">
      <div className="card border-0 shadow-lg rounded-4 overflow-hidden">
        {/* Header */}
        <div className="card-header bg-primary text-center py-2 text-white">
          <h1 className="mb-0">Payroll Summary Report</h1>
        </div>

        <div className="card-body bg-light p-2">
          {/* Search */}
          <div className="mb-3">
            <input
              type="text"
              className="form-control"
              placeholder="Search by employee name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {/* Loading/Error */}
          {loading && <p className="text-center">Loading data...</p>}
          {error && <p className="text-center text-danger">{error}</p>}

          {/* Table */}
          {!loading && !error && (
            <div className="table-responsive">
              <table className="table table-bordered table-striped text-center mb-0">
                <thead className="text-white" style={{ backgroundColor: "#0c3f7e" }}>
                  <tr>
                    <th>Employee Name</th>
                    <th>Basic Salary</th>
                    <th>HRA</th>
                    <th>Medical</th>
                    <th>Tax</th>
                    <th>PF</th>
                    <th>Gross Salary</th>
                    <th>Net Salary</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.length > 0 ? (
                    filteredEmployees.map((emp) => (
                      <tr key={emp.emp_id}>
                        <td>{emp.emp_name}</td>
                        <td>{emp.basic_salary}</td>
                        <td>{emp.hra}</td>
                        <td>{emp.medical_allowance}</td>
                        <td>{emp.tax_deduction}</td>
                        <td>{emp.pf_deduction}</td>
                        <td>{emp.gross_salary}</td>
                        <td>{emp.net_salary}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="8" className="text-center text-danger py-3">
                        No employee found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaySumRep;
