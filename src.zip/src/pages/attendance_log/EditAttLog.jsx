import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditAttLog = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { attlogId } = useParams();

  const [attendance_logs, setAttendanceLog] = useState({
    id: "",
    source: "",
    in_time: "",
    out_time: "",
    status: "",
    grace_time: "",
    late_time: "",
    total_work_minutes: "",
    remark: ""
  });

  const navigate = useNavigate();

  // Fetch attendance log data
  const fetchAttendanceLog = () => {
    axios
      .get(`${baseUrl}/attendance_logs/find/${attlogId}`)
      .then((res) => {
        const log = res.data.attendance_logs;
        setAttendanceLog({
          id: log.id,
          source: log.source,
          in_time: log.in_time,
          out_time: log.out_time,
          status: log.status,
          grace_time: log.grace_time,
          late_time: log.late_time,
          total_work_minutes: log.total_work_minutes,
          remark: log.remarks || "" // fallback
        });
      })
      .catch((err) => console.log("Fetch Error:", err));
  };

  useEffect(() => {
    fetchAttendanceLog();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setAttendanceLog((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .put(`${baseUrl}/attendance_logs/update`, attendance_logs)
      .then((res) => {
        console.log("Updated:", res.data);
        navigate("/attendance_logs");
      })
      .catch((err) => console.log("Update Error:", err));
  };

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: "800px",
        margin: "20px auto",
        padding: "20px",
        border: "1px solid #ccc",
        borderRadius: "8px"
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: "pointer" }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Edit Attendance Log</h3>

      <form onSubmit={handleSubmit} className="row g-3">
        {/* Source */}
        <div className="col-md-6">
          <label className="form-label">Source</label>
          <input
            type="text"
            name="source"
            value={attendance_logs.source}
            onChange={handleChange}
            className="form-control"
            placeholder="Manual / Device / App"
            required
          />
        </div>

        {/* In Time */}
        <div className="col-md-6">
          <label className="form-label">In Time</label>
          <input
            type="time"
            name="in_time"
            value={attendance_logs.in_time}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Out Time */}
        <div className="col-md-6">
          <label className="form-label">Out Time</label>
          <input
            type="time"
            name="out_time"
            value={attendance_logs.out_time}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Status */}
        <div className="col-md-6">
          <label className="form-label">Status</label>
          <select
            name="status"
            value={attendance_logs.status}
            onChange={handleChange}
            className="form-control"
            required
          >
            <option value="">Select Status</option>
            <option value="working-day">Working-Day</option>
            <option value="weekend-day">Weekend-Day</option>
          </select>
        </div>

        {/* Grace Time */}
        <div className="col-md-6">
          <label className="form-label">Grace Time (minutes)</label>
          <input
            type="number"
            name="grace_time"
            value={attendance_logs.grace_time}
            onChange={handleChange}
            className="form-control"
            placeholder="e.g. 10"
          />
        </div>

        {/* Late Time */}
        <div className="col-md-6">
          <label className="form-label">Late Time (minutes)</label>
          <input
            type="number"
            name="late_time"
            value={attendance_logs.late_time}
            onChange={handleChange}
            className="form-control"
            placeholder="e.g. 5"
          />
        </div>

        {/* Total Work Minutes */}
        <div className="col-md-6">
          <label className="form-label">Total Work Minutes</label>
          <input
            type="number"
            name="total_work_minutes"
            value={attendance_logs.total_work_minutes}
            onChange={handleChange}
            className="form-control"
            placeholder="Auto / Manual"
          />
        </div>

        {/* Remarks */}
        <div className="col-md-12">
          <label className="form-label">Remarks</label>
          <textarea
            name="remark"
            value={attendance_logs.remark}
            onChange={handleChange}
            className="form-control"
            rows="3"
            placeholder="Write remarks..."
          ></textarea>
        </div>

        {/* Submit Button */}
        <div className="col-12 text-end">
          <button type="submit" className="btn btn-success px-4">
            Save Attendance
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditAttLog;
