import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateAttenLog = () => {
  const [attendancelog, setAttendancelog] = useState({
    source: '',
    in_time: '',
    out_time: '',
    status: '',
    grace_time: '',
    late_time: '',
    total_work_minutes: '',
    remark: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setAttendancelog((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitting attendance log:', attendancelog);

    axios.post('http://localhost:8080/PHP_Converted/admin/api/attendance_logs/save.php', attendancelog)
      .then((res) => {
        console.log(res.data);
        navigate('/attendance_logs'); // redirect after successful creation
      })
      .catch((err) => console.log('Submit Error:', err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1); // go to previous page
  };

  return (
    <div
      style={{
        maxWidth: '600px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Create Attendance Log</h3>

      <form onSubmit={handleSubmit}>
        {/* Source */}
        <div className="mb-3">
          <label htmlFor="source" className="form-label">Source</label>
          <select
            id="source"
            name="source"
            value={attendancelog.source}
            onChange={handleChange}
            className="form-control"
            required
          >
            <option value="">Select Type</option>
            <option value="biometric">Biometric</option>
            <option value="manual">Manual</option>
            <option value="web">Web</option>
          </select>
        </div>

        {/* In Time */}
        <div className="mb-3">
          <label htmlFor="in_time" className="form-label">In Time</label>
          <input
            type="time"
            id="in_time"
            name="in_time"
            value={attendancelog.in_time}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Out Time */}
        <div className="mb-3">
          <label htmlFor="out_time" className="form-label">Out Time</label>
          <input
            type="time"
            id="out_time"
            name="out_time"
            value={attendancelog.out_time}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Status */}
        <div className="mb-3">
          <label htmlFor="status" className="form-label">Status</label>
          <select
            id="status"
            name="status"
            value={attendancelog.status}
            onChange={handleChange}
            className="form-control"
            required
          >
            <option value="">Select Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        {/* Grace Time */}
        <div className="mb-3">
          <label htmlFor="grace_time" className="form-label">Grace Time</label>
          <input
            type="time"
            id="grace_time"
            name="grace_time"
            value={attendancelog.grace_time}
            onChange={handleChange}
            className="form-control"
          />
        </div>

        {/* Late Time */}
        <div className="mb-3">
          <label htmlFor="late_time" className="form-label">Late Time</label>
          <input
            type="time"
            id="late_time"
            name="late_time"
            value={attendancelog.late_time}
            onChange={handleChange}
            className="form-control"
          />
        </div>

        {/* Total Work Minutes */}
        <div className="mb-3">
          <label htmlFor="total_work_minutes" className="form-label">Total Work Minutes</label>
          <input
            type="number"
            id="total_work_minutes"
            name="total_work_minutes"
            value={attendancelog.total_work_minutes}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter total work minutes"
          />
        </div>

        {/* Remark */}
        <div className="mb-3">
          <label htmlFor="remark" className="form-label">Remark</label>
          <input
            type="text"
            id="remark"
            name="remark"
            value={attendancelog.remark}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter remarks"
          />
        </div>

        {/* Submit Button */}
        <div className="text-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateAttenLog;
