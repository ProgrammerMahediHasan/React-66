import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import "./pagination.css";
const LeaveConfigList = () => {

  const [leave_configuration, setLeaveConfiguration] = useState([]);


  const getLeaveConfiguration = () => {
    
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/LeaveConfiguration/",
      method: "GET",
      data: {}
    })

      .then((res) => {
        setLeaveConfiguration(res.data.leave_configuration);
      })

      .catch((err) => {
        console.log(err);
      });

  };

  useEffect(() => {
    getLeaveConfiguration();
  }, []);

  // ✅ Delete function
  const deleteleave_configuration = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this Leave Configuration?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/LeaveConfiguration/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(() => {
        getLeaveConfiguration();
      })
      .catch(err => console.log(err));
  };

  // ✅ Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;


  // ✅ Pagination Logic
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = leave_configuration.slice(indexOfFirstRow, indexOfLastRow);

  const totalPages = Math.ceil(leave_configuration.length / rowsPerPage);

  return (
    <>
      <h1 className="text-center my-4">Employee Leave Configuration</h1>

      <div className="container" style={{ paddingBottom: "80px" }}>
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/LeaveConfiguration/create" className="btn btn-success">
            Add Leave Configuration
          </Link>
        </div>

        <div className="container">
          <table className="table table-bordered table-striped">
            <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
              <tr>
                <th>ID</th>
                <th>Leave Type</th>
                <th>Total Days</th>
                <th>Carry Forward</th>
                <th>Description</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {currentRows.map((LeaveConfiguration, i) => (
                <tr key={i}>
                  <td>{LeaveConfiguration.id}</td>
                  <td>{LeaveConfiguration.leave_type}</td>
                  <td>{LeaveConfiguration.total_days}</td>
                  <td>{LeaveConfiguration.carry_forward}</td>
                  <td>{LeaveConfiguration.description}</td>
                  <td>{LeaveConfiguration.status}</td>
                  <td>
                    <Link
                      to={`/LeaveConfiguration/edit/${LeaveConfiguration.id}`}
                      className="btn btn-info me-2"
                    >
                      Edit
                    </Link>

                    <button
                      onClick={() => deleteleave_configuration(leave_configuration.id)}
                      className="btn btn-danger"
                      style={{ width: "50px" }}
                    >
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

{/* Pagination  */}


<div className="pagination">

  <a
    className={currentPage === 1 ? "disabled" : ""}
    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
  >
    « Previous
  </a>

  {[...Array(totalPages)].map((_, index) => (
    <a
      key={index}
      className={currentPage === index + 1 ? "active" : ""}
      onClick={() => setCurrentPage(index + 1)}
    >
      {index + 1}
    </a>
  ))}

  <a
    className={currentPage === totalPages ? "disabled" : ""}
    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
  >
    Next »
  </a>

</div>

        

        </div>
      </div>
    </>
  );
};

export default LeaveConfigList;
