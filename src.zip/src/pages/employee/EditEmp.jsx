import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditEmp = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { empId } = useParams();

  const [employee, setEmployee] = useState({
    id: '',
    name: '',
    dept_id: '',
    desig_id: '',
    gender: '',
    email: '',
    phone: '',
    status: '',
    joining_date: ''
  });

  const navigate = useNavigate();

  // Fetch employee data
  function fetchemployee() {
   axios({
  url: `${baseUrl}/employee/find/${empId}`,
  method: "GET",
  data: {}
})
.then((res) => {
  console.log(res.data.employee);
  setEmployee({
    id: res.data.employee.id,
    name: res.data.employee.name,
    dept_id: res.data.employee.dept_id,
    desig_id: res.data.employee.desig_id,
    gender: res.data.employee.gender,
    email: res.data.employee.email,
    phone: res.data.employee.phone,
    status: res.data.employee.status,
    joining_date: res.data.employee.joining_date
  });
})

      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchemployee();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/employee/update`,
      method: "PUT",
      data:  employee 
    })
      .then((res) => {
        console.log(res.data);
        navigate("/employee");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
        <div
        style={{
          maxWidth: '800px', // width increased
          margin: '20px auto',
          padding: '20px',
          border: '1px solid #ccc',
          borderRadius: '8px'
        }}
        >

      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Edit Employee Information</h3>

      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="">Name</label> <br />
          <input
            value={employee.name}
            name='employeename'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div>
          <label htmlFor="">Deparment</label> <br />
          <input
            value={employee.dept_id}
            name='password'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div>
          <label htmlFor="">Designation</label> <br />
          <input
            value={employee.desig_id}
            name='email'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div>
          <label htmlFor="">Email</label> <br />
          <input
            value={employee.email}
            name='address'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <div>
          <label htmlFor="">Phone</label> <br />
          <input
            value={employee.phone}
            name='address'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

       <div className="mb-3">
  <label htmlFor="status" className="form-label">Status</label>
  <select
    id="status"
    name="status"
    value={employee.status}
    onChange={handleChange}
    className="form-control"
  >
    <option value="">Select status</option>
    <option value="active">Active</option>
    <option value="inactive">Inactive</option>
  </select>
</div>

       <div className="mb-3">
  <label htmlFor="gender" className="form-label">Gender</label>
  <select
    id="gender"
    name="gender"
    value={employee.gender}
    onChange={handleChange}
    className="form-control"
  >
    <option value="">Select Gender</option>
    <option value="male">Male</option>
    <option value="female">Female</option>
  </select>
</div>

        <div>
          <label htmlFor="">Hiring Date</label> <br />
          <input
            value={employee.joining_date}
            name='address'
            type="text"
            onChange={handleChange}
            className="form-control"
          />
        </div>

        


        <br />
        <br />
        <div>
          <button type="submit" className="btn btn-success">Update</button>
        </div>
      </form>
    </div>
  );
};

export default EditEmp;
