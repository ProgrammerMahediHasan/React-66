import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
// import Header from '../../Layout/Header';
// import Footer from '../../Layout/Footer';
import 'bootstrap-icons/font/bootstrap-icons.css'; // ✅ Bootstrap Icons import

const DeptList = () => {

  const [department, setdepartment] = useState([]);

  const getdepartment = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/department/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.department);
        setdepartment(res.data.department);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  useEffect(() => {
    getdepartment();
  }, []);

  // Delete function 
  const deletedepartment = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this department?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/department/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data.department);
        getdepartment(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };



 // ✅ Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;


  // ✅ Pagination Logic
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = department.slice(indexOfFirstRow, indexOfLastRow);

  const totalPages = Math.ceil(department.length / rowsPerPage);

  return (
    <>
      {/* <Header /> */}
      <h1 className="text-center my-4">Department List</h1>

      <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/department/create" className="btn btn-success">
            Add Department
          </Link>
        </div>

        <div className="container">
          <table className="table table-bordered table-striped">
            <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
              <tr>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Status</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>

           <tbody>
     {department.map((dept, index) => (
    <tr key={dept.id}>
      <th scope="row">{index + 1}</th>
      <td>{dept.name}</td>
      <td>{dept.description}</td>
      <td>{dept.status}</td>
      <td className="d-flex justify-content-start gap-2">


                  {/* Edit button with icon */}
                  <Link  to={`/department/edit/${dept.id}`} 
                  className="btn btn-info" 
                  style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                  <i className="bi bi-pencil-square"></i>
                  </Link> 
                  {/* Delete button with icon */}
                  <button
                    onClick={() => deletedepartment(dept.id)}
                    className="btn btn-danger"
                    style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                    <i className="bi bi-trash"></i>
                  </button>


      </td>
    </tr>
  ))}
</tbody>
          </table>


{/* Pagination  */}


<div className="pagination">

  <a
    className={currentPage === 1 ? "disabled" : ""}
    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
  >
    « Previous
  </a>

  {[...Array(totalPages)].map((_, index) => (
    <a
      key={index}
      className={currentPage === index + 1 ? "active" : ""}
      onClick={() => setCurrentPage(index + 1)}
    >
      {index + 1}
    </a>
  ))}

  <a
    className={currentPage === totalPages ? "disabled" : ""}
    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
  >
    Next »
  </a>

</div>

        </div>
      </div>

    </>
  );
};

export default DeptList;
