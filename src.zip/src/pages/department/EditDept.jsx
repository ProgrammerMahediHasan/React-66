import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditDesig = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { deptId } = useParams();

  const [department, setDept] = useState({
    id: '',
    name: '',
    description: '',
    status: ''
  });

  const navigate = useNavigate();

  // Fetch user data
  function fetchDesig() {
   axios({
  url: `${baseUrl}/department/find/${deptId}`,
  method: "GET",
  data: {}
})
.then((res) => {
  console.log(res.data.department);
  setDept({
    id: res.data.department.id,
    name: res.data.department.name,
    description: res.data.department.description
  });
})

      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchDesig();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setDept(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/department/update`,
      method: "PUT",
      data:  department 
    })
      .then((res) => {
        console.log(res.data);
        navigate("/department");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (


<div
  style={{
    maxWidth: '800px',       // container বড় করা
    margin: '50px auto',
    padding: '40px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    boxShadow: '0 6px 12px rgba(0,0,0,0.1)',
    backgroundColor: '#fff'
  }}
>
  {/* Back Button */}
  <button
    onClick={handleBack}
    className="btn btn-secondary mb-4"
    style={{ cursor: 'pointer' }}
  >
    &larr; Back
  </button>

  <h3 className="text-center mb-5">Edit department</h3>

  <form onSubmit={handleSubmit}>
    <div className="mb-4">
      <label htmlFor="" style={{ fontSize: '16px', fontWeight: '500' }}>Name</label>
      <input
        value={department.name}
        name='name'
        type="text"
        onChange={handleChange}
        className="form-control"
        style={{ width: '100%', height: '50px', fontSize: '16px' }} // full width এবং বড় height
      />
    </div>

    <div className="mb-4">
      <label htmlFor="" style={{ fontSize: '16px', fontWeight: '500' }}>Description</label>
      <input
        value={department.description}
        name='description'
        type="text"
        onChange={handleChange}
        className="form-control"
        style={{ width: '100%', height: '50px', fontSize: '16px' }}
      />
    </div>

   <div className="mb-4">
  <label htmlFor="status" style={{ fontSize: '16px', fontWeight: '500' }}>Status</label>
  <select
    id="status"
    name='status' // এখানে নামও ঠিক করা হলো
    value={department.status}
    onChange={handleChange}
    className="form-control"
    style={{ width: '100%', height: '50px', fontSize: '16px' }}
  >
    <option value="">Select status</option>
    <option value="active">Active</option>
    <option value="inactive">Inactive</option>
  </select>
</div>


    <div className="text-center">
      <button type="submit" className="btn btn-success btn-lg">Update</button>
    </div>
  </form>
</div>



  );
};

export default EditDesig;
