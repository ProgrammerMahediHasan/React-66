import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateDailyAttendance = () => {
  const [daily_attendance, setDailyAttendance] = useState({
       id: '',
    emp_id: '',
    att_date: '',
    day_type: '',
    in_time: '',
    out_time: '',
    total_work_minutes: '',
    status: '',
    late_minutes: '',
    overtime_minutes: '',
    remarks: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setDailyAttendance((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitting daily_attendance:', daily_attendance);

    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/save',
      method: 'POST',
      data: daily_attendance
    })
      .then((res) => {
        console.log(res.data.daily_attendance);
        if (res) {
          navigate('/daily_attendance'); // redirect to user list after successful creation
        }
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1); // go to previous page
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Create Daily Attendance</h3>
     <form onSubmit={handleSubmit}>
  {/* Employee ID */}
  <div className="mb-3">
    <label className="form-label">Employee ID</label>
    <input
      type="text"
      name="emp_id"
      value={daily_attendance.emp_id}
      onChange={handleChange}
      className="form-control"
      placeholder="Enter employee ID"
      required
    />
  </div>

  {/* Attendance Date */}
  <div className="mb-3">
    <label className="form-label">Attendance Date</label>
    <input
      type="date"
      name="att_date"
      value={daily_attendance.att_date}
      onChange={handleChange}
      className="form-control"
      required
    />
  </div>

  {/* Day Type */}
  <div className="mb-3">
    <label className="form-label">Day Type</label>
    <select
      name="day_type"
      value={daily_attendance.day_type}
      onChange={handleChange}
      className="form-control"
      required
    >
      <option value="">Select Day Type</option>
      <option value="working">Working Day</option>
      <option value="weekend">Weekend</option>
      <option value="holiday">Holiday</option>
    </select>
  </div>

  {/* In Time */}
  <div className="mb-3">
    <label className="form-label">In Time</label>
    <input
      type="time"
      name="in_time"
      value={daily_attendance.in_time}
      onChange={handleChange}
      className="form-control"
    />
  </div>

  {/* Out Time */}
  <div className="mb-3">
    <label className="form-label">Out Time</label>
    <input
      type="time"
      name="out_time"
      value={daily_attendance.out_time}
      onChange={handleChange}
      className="form-control"
    />
  </div>

  {/* Total Work Minutes */}
  <div className="mb-3">
    <label className="form-label">Total Work Minutes</label>
    <input
      type="number"
      name="total_work_minutes"
      value={daily_attendance.total_work_minutes}
      onChange={handleChange}
      className="form-control"
      placeholder="Enter total work minutes"
    />
  </div>

  {/* Status */}
  <div className="mb-3">
    <label className="form-label">Status</label>
    <select
      name="status"
      value={daily_attendance.status}
      onChange={handleChange}
      className="form-control"
      required
    >
      <option value="">Select Status</option>
      <option value="present">Present</option>
      <option value="absent">Absent</option>
      <option value="leave">Leave</option>
    </select>
  </div>

  {/* Late Minutes */}
  <div className="mb-3">
    <label className="form-label">Late Minutes</label>
    <input
      type="number"
      name="late_minutes"
      value={daily_attendance.late_minutes}
      onChange={handleChange}
      className="form-control"
      placeholder="Enter late minutes"
    />
  </div>

  {/* Overtime Minutes */}
  <div className="mb-3">
    <label className="form-label">Overtime Minutes</label>
    <input
      type="number"
      name="overtime_minutes"
      value={daily_attendance.overtime_minutes}
      onChange={handleChange}
      className="form-control"
      placeholder="Enter overtime minutes"
    />
  </div>

  {/* Remarks */}
  <div className="mb-3">
    <label className="form-label">Remarks</label>
    <textarea
      name="remarks"
      value={daily_attendance.remarks}
      onChange={handleChange}
      className="form-control"
      rows="3"
      placeholder="Write remarks..."
    ></textarea>
  </div>

  {/* Submit Button */}
  <div className="text-center">
    <button type="submit" className="btn btn-primary">
      Submit
    </button>
  </div>
</form>

    </div>
  );
};

export default CreateDailyAttendance;
