import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
// import Header from '../../Layout/Header';
// import Footer from '../../Layout/Footer';

const EmpList = () => {

  const getemployee = () => {
    axios({
      url: "http://localhost/PHP_Converted/admin/api/employee/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.employees);
        setemployee(res.data.employees)
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const [employee, setemployee] = useState([]);

  useEffect (() => {getemployee()},[]);

  // Delete function 
  const deleteemployee = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this employee details?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/employee/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data.employee);
        getemployee(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


  return (
    
<>

{/* <Header /> */}
  <h1 className="text-center my-4">Employee Information</h1>

  <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/employee/create" className="btn btn-success">
            Add Employee
          </Link>
        </div>

  <div className="container">
    <table className="table table-bordered table-striped">
      <thead className="table-dark">
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Name</th>
          <th scope="col">Department</th>
          <th scope="col">Designation</th>
          <th scope="col">Gender</th>
          <th scope="col">Gmail</th>
          <th scope="col">Contact</th>
          <th scope="col">Status</th>
          <th scope="col">Hire Date</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        {employee.map((emp, i) => (
          <tr key={i}>
            <th scope="row">{++i}</th>
            <td>{emp.name}</td>
            <td>{emp.department}</td>
            <td>{emp.designation}</td>
            <td>{emp.gender}</td>
            <td>{emp.email}</td>
            <td>{emp.phone}</td>
            <td>{emp.status}</td>
            <td>{emp.joining_date}</td>
            <td>
              <Link 
  to={`/employee/edit/${emp.id}`} 
  className="btn btn-info me-2"
>
  Edit
</Link>

 {/* Delete button with icon */}
         <button
          onClick={() => deleteemployee(emp.id)}
          className="btn btn-danger"
          style={{ width: "50px", display: "flex", justifyContent: "center" }}>
          <i className="bi bi-trash"></i>
        </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  </div>
  {/* <Footer /> */}
</>


  );
};

export default EmpList;
