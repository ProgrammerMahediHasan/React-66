import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateEmp = () => {
  const [employee, setemployee] = useState({
    name: '',
    dept_id: '',
    desig_id: '',
    gender: '',
    email: '',
    phone: '',
    status: '',
    joining_date: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setemployee((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitting employee:', employee);

    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/employee/save',
      method: 'POST',
      data: employee
    })
      .then((res) => {
        console.log(res.data.employee);
        if (res) {
          navigate('/employee'); // redirect to user list after successful creation
        }
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1); // go to previous page
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Create Employee</h3>
      <form onSubmit={handleSubmit}>
        {/* Username */}
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={employee.name}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter name"
            required
          />
        </div>


        <div className="mb-3">
          <label htmlFor="dept_id" className="form-label">Department</label>
          <input
            type="dept_id"
            id="dept_id"
            name="dept_id"
            value={employee.dept_id}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter description"
            required
          />
        </div>


        {/* Submit Button */}
        <div className="text-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateEmp;
