import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditDept = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { deptId } = useParams(); // department id

  const [department, setDepartment] = useState({
    id: '',
    name: '',
    description: '',
    status: ''
  });

  const navigate = useNavigate();

  // Fetch department data
  function fetchDepartment() {
    axios({
      url: `${baseUrl}/department/find/${deptId}`,
      method: "GET",
    })
      .then((res) => {
        console.log(res.data);
        setDepartment({
          id: res.data.department.id,
          name: res.data.department.name,
          description: res.data.department.description,
          status: res.data.department.status
        });
      })
      .catch((err) => console.log(err));
  }

  useEffect(() => {
    fetchDepartment();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setDepartment(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();
    axios({
      url: `${baseUrl}/department/update`,
      method: "PUT",
      data: department
    })
      .then((res) => {
        console.log(res.data);
        navigate("/department");
      })
      .catch((err) => console.log(err));
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >

      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Edit Department</h3>

      <form onSubmit={handleSubmit}>
        {/* Hidden ID */}
        <input type="hidden" name="id" value={department.id} />

        <label>Department Name</label>
        <input
          name="name"
          value={department.name}
          onChange={handleChange}
          type="text"
          className="form-control"
        />

        <label>Description</label>
        <textarea
          name="description"
          value={department.description}
          onChange={handleChange}
          className="form-control"
          rows="3"
        />

        <label>Status</label>
        <input
          name="status"
          value={department.status}
          onChange={handleChange}
          type="text"
          className="form-control"
        />

        <br />

        <button type="submit" className="btn btn-success">Update</button>
      </form>
    </div>
  );
};

export default EditDept;
