import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
// import Header from '../../Layout/Header';
// import Footer from '../../Layout/Footer';

const AttenLogList = () => {

  const getAttendanceLog = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/AttendanceLog/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.attendance_logs);
        setAttendanceLog(res.data.attendance_logs)
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const [attendance_logs, setAttendanceLog] = useState([]);

  useEffect (() => {getAttendanceLog()},[]);

  // Delete function 
  const deleteattendance_logs = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this attendance_logs?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/AttendanceLog/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data.attendance_logs);
        getAttendanceLog(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


  return (
    
<>

{/* <Header /> */}
  <h1 className="text-center my-4">Employee Information</h1>

  <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/AttendanceLog/create" className="btn btn-success">
            Add AttendanceLog
          </Link>
        </div>

  <div className="container">
    <table className="table table-bordered table-striped">
      <thead className="table-dark">
        <tr>
          <th scope="col">Attendance Type</th>
          <th scope="col">Attend In</th>
          <th scope="col">Attend Out</th>
          <th scope="col">Status</th>
          <th scope="col">Grace Time</th>
          <th scope="col">Late Time</th>
          <th scope="col">Total Minutes</th>
          <th scope="col">Remarks</th>
          {/* <th scope="col">id</th> */}
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        {attendance_logs.map((AttendanceLog, i) => (
          <tr key={i}>
            {/* <th scope="row">{++i}</th> */}
            <td>{AttendanceLog.source}</td>
            <td>{AttendanceLog.in_time}</td>
            <td>{AttendanceLog.out_time}</td>
            <td>{AttendanceLog.status}</td>
            <td>{AttendanceLog.grace_time}</td>
            <td>{AttendanceLog.late_time}</td>
            <td>{AttendanceLog.total_work_minutes}</td>
            <td>{AttendanceLog.remakrs}</td>
            {/* <td>{AttendanceLog.id}</td> */}
            <td>
              <Link 
  to={`/AttendanceLog/edit/${AttendanceLog.id}`} 
  className="btn btn-info me-2"
>
  Edit
</Link>

 {/* Delete button with icon */}
         <button
          onClick={() => deleteattendance_logs(attendance_logs.id)}
          className="btn btn-danger"
          style={{ width: "50px", display: "flex", justifyContent: "center" }}>
          <i className="bi bi-trash"></i>
        </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  </div>
  {/* <Footer /> */}
</>


  );
};

export default AttenLogList;
